import { Link } from "react-router-dom";


export default function PagePok({ pokemon }) {

    return <>


        <table class="DétailsPokTable">
            <thead>
                <tr><th>Types</th><th>Weaknesses</th><th>Multipliers</th><th>Prev-evolution</th><th>Next-evolution</th><th>Height</th><th>Weight</th><th>Candy</th>
                    <th>Candy count</th><th>Egg</th><th>Spawn chance</th><th>Avg spawns</th><th>Spawn time</th></tr>
            </thead>
            <tbody>
                <tr>
                    {pokemon.type ? <td>{pokemon.type.map((type) => <p>{type}</p>)}</td> : <td>None</td>}
                    {pokemon.weaknesses ? <td>{pokemon.weaknesses.map((weaknesses) => <p>{weaknesses}</p>)}</td> : <td>None</td>}
                    {pokemon.multipliers ? <td>{pokemon.multipliers.map((multiplier) => <p>{multiplier}</p>)}</td> : <td>None</td>}
                    {pokemon.prev_evolution ? <td>{pokemon.prev_evolution.map(prev_evolution => <p key={prev_evolution.num}> {prev_evolution.name}</p>)}</td> : <td>None</td>}
                    {pokemon.next_evolution ? <td>{pokemon.next_evolution.map(next_evolution => <p key={next_evolution.num}> {next_evolution.name}</p>)}</td> : <td>None</td>}
                    {pokemon.height ? <td>{pokemon.height}</td> : <td>None</td>}
                    {pokemon.weight ? <td>{pokemon.weight}</td> : <td>None</td>}
                    {pokemon.candy ? <td>{pokemon.candy}</td> : <td>None</td>}
                    {pokemon.candy_count ? <td>{pokemon.candy_count}</td> : <td>None</td>}
                    {pokemon.egg ? <td>{pokemon.egg}</td> : <td>None</td>}
                    {pokemon.spawn_chance ? <td>{pokemon.spawn_chance * 100} %</td> : <td>None</td>}
                    {pokemon.avg_spawns ? <td>{pokemon.avg_spawns}</td> : <td>None</td>}
                    {pokemon.spawn_time ? <td>{pokemon.spawn_time}</td> : <td>None</td>}
                </tr>
                <tr>
                    <img src={pokemon.img}></img>
                    <Link to="/">Back</Link>
                </tr>
            </tbody>
        </table>
    </>
    /* "height": "0.71 m",
    "weight": "6.9 kg",
    "candy": "Bulbasaur Candy",
    "candy_count": 25,
    "egg": "2 km",
    "spawn_chance": 0.69,
    "avg_spawns": 69,
    "spawn_time": "20:00", */
}