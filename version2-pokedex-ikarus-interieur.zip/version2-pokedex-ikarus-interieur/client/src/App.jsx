
import './App.css';
import React from 'react';
import PagePok from './pages/PagePok';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Pokedex from './pages/Pokedex';


class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = { apiResponse: "" }
  }
  callAPI() {
    fetch("http://localhost:9000/testAPI")
      .then(res => res.text())
      .then(res => this.setState({ apiResponse: res }));
  }
  //Le moment où le composant est initialisé au navigateur on execute la fonction callAPI, qui va call le back end 
  componentWillMount() {
    this.callAPI()
  }

  //dans le rendu client on va afficher le contenu de la réponse
  render() {
    let pokemonsStr = this.state.apiResponse.toString();

    let pokemonsArray = [];

    if (pokemonsStr) {
      let pokemonsObject = JSON.parse(pokemonsStr);

      pokemonsArray = Array.from(pokemonsObject);

    } else {
      console.log("error")
    }

    return (
      <BrowserRouter>
        <Routes>
          {pokemonsArray.map((pokemon, index) => <><Route path={"/" + pokemon.name} element={<PagePok pokemon={pokemon} ></PagePok>} />  <Route path={"/"} element={<Pokedex pokemonsArray={pokemonsArray}></Pokedex>} /> </>)}
        </Routes>
      </BrowserRouter>
    );
  }
}





export default App;
