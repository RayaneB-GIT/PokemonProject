


const pokedex = require('./pokedex.json')

var express = require("express");


var router = express.Router();


router.get("/", function (req, res, next) {
    res.send(pokedex);
})

module.exports = router;

//il faut faire la commande npm install --save cors
//car il va autoriser à un autre application de l`acceder à lui sinon il le block